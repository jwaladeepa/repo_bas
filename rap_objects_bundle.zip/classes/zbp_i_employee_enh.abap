##Step 8: ABAP Class creation

CLASS zbp_i_employee_enh DEFINITION PUBLIC ABSTRACT FINAL FOR BEHAVIOR OF zi_employee_enh.
ENDCLASS.

CLASS zbp_i_employee_enh IMPLEMENTATION.
ENDCLASS.
